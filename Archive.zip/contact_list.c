#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact_list.h"


/**************************
 *   Declaring Functions  *
 **************************/

void flush_in(void) {

	char ch;

   while( (ch = fgetc(stdin)) != EOF && ch != '\n' ); 
}


void create_list(node **head) { 

	//Create empty list.

	*head = NULL;

}


void add_contact(node **head) {

	//Allocating a node. 
	node *new_node = (node*)malloc(sizeof(node));

	//Checking a node.
	if(new_node == NULL) {

		fprintf(stderr, "\nThere was a problem while creating the list...\n\n");
		exit(EXIT_FAILURE);

	}

	//Initializing a node.

	printf("\nName: ");
	fgets(new_node->person.name, sizeof(new_node->person.name), stdin);
	new_node->person.name[strcspn(new_node->person.name, "\n")] = '\0'; //Remove \n.

	printf("\nNumber: ");
	fgets(new_node->person.number, sizeof(new_node->person.number), stdin);
	new_node->person.number[strcspn(new_node->person.number, "\n")] = '\0'; //Remove \n.

	printf("\nBirthday (DD/MM/YYYY): ");
	scanf("%2d/%2d/%4d", &new_node->person.birthday.day, &new_node->person.birthday.month,
		&new_node->person.birthday.year);
	flush_in();

	if((*head == NULL) || (strcmp(new_node->person.name, (*head)->person.name) < 0)) {

		new_node->next = *head;
		*head = new_node;

	}

	else {

		node *current = (*head)->next;
		node *previous = *head;

		while((current != NULL) && (strcmp(new_node->person.name, current->person.name) > 0)) {

			previous = current;
			current = current->next;

		}

		new_node->next = current;
		previous->next = new_node;

	}

}

void print_contact(node *contact_node) {


		printf("\nName: %s", contact_node->person.name);
		printf("\nNumber: %s", contact_node->person.number);
		printf("\nBirthday: %02d/%02d/%4d\n", contact_node->person.birthday.day, contact_node->person.birthday.month,
			contact_node->person.birthday.year);


}


void print_list(node *head){

	node *current = head;

	while(current != NULL) {

		print_contact(current);

		current = current->next;
	}
}

int remove_contact(node **head) {

	char remove_name[30];

	printf("\nName of the contact to be removed: ");
	fgets(remove_name, sizeof(remove_name), stdin);
	remove_name[strcspn(remove_name, "\n")] = '\0';

	if(strcmp(remove_name, (*head)->person.name) == 0) {

		node *old_head = *head;
		*head = (*head)->next;

		free(old_head);

		return 1;

	}

	else {

		node *previous = *head;
		node *current = (*head)->next;

		while((current != NULL) && (strcmp(remove_name, current->person.name) != 0)) {

			previous = current;
			current = current->next;

		}

		if(current == NULL) {

			return 0;

		}

		else {

			previous->next = current->next;

			free(current);

			return 1;

		}
	}
}

void search_contact(node *head) {

	char search_name[30];

	printf("\nName of the contact to be found: ");
	fgets(search_name, sizeof(search_name), stdin);
	search_name[strcspn(search_name, "\n")] = '\0';

	node *current = head;

	while((current != NULL) && (strcmp(search_name, current->person.name) != 0)) {

		current = current->next;

	}

	if(current == NULL) {

		printf("\nContact not found...");

	}

	else {

		print_contact(current);

	}
}

void search_letter(node *head) {

	char search_char;

	printf("\nLetter: ");
	search_char = getchar();
	flush_in();

	node *current = head;

	while((current != NULL) && (current->person.name[0] <= search_char)) {


		if(current->person.name[0] == search_char) {

			print_contact(current);
		}

		current = current->next;
	}
}

void search_birthday(node *head) {

	int search_month;

	printf("\nMonth: ");
	scanf("%d", &search_month);
	flush_in();

	node *current = head;

	while(current != NULL) {

		if(current->person.birthday.month == search_month) {

			print_contact(current);
		}

		current = current->next;
	}
}



