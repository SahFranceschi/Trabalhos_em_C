
/***************************
 *    Defining Structs     *
 ***************************/

struct data {

	int day;
	int month;
	int year;

};

typedef struct data data;

struct contact {

	char name[30];
	char number[20];
	data birthday;

};

typedef struct contact contact;

struct node {

	contact person;
	struct node *next;

};

typedef struct node node;


/***************************
 *    Defining Functions   *
 ***************************/

void flush_in(void);

void create_list(node **head);

void add_contact(node **head);

void print_contact(node *contact_node);

void print_list(node *head);

int remove_contact(node **head);

void search_contact(node *head);

void search_letter(node *head);

void search_birthday(node *head);

