#include <stdio.h>
#include <stdlib.h>
#include "contact_list.h"

int show_menu(void);


int main() {

	int option;
	node *head;
	create_list(&head);

	while((option = show_menu()) != 7) {

		switch(option) {

			case 1:

				//Adiciona contato
				add_contact(&head);
				break;

			case 2:

				//Remover contato
				if(remove_contact(&head) == 1) {

					fprintf(stderr, "\nContact removed with success.\n");
				}

				else {

					fprintf(stderr, "\nContact not found...\n");
				}

				break;

			case 3:

				//Procurar por um contato 
				search_contact(head);
				break;

			case 4: 

				//Listar todos os contatos
				print_list(head);
				break;

			case 5:

				//Listar todos os contatos que começam com uma letra
				search_letter(head);
				break;

			case 6:

				//Listar aniversariantes de um determnado mes
				search_birthday(head);
				break;

			default:

				;

		}
	}

	return 0;

}


int show_menu(void) {

	int num;

	printf("\n\n************************************************************\n");
	printf("                              MENU                              ");
	printf("\n************************************************************\n");		
	printf("*                      1 -> Add contact                    *\n");
	printf("************************************************************");
	printf("\n*                    2 -> Remove contact                   *\n");
	printf("************************************************************");
	printf("\n*                 3 -> Search for a contact                *\n");
	printf("************************************************************");
	printf("\n*                  4 -> List all contacts                  *\n");
	printf("************************************************************");
	printf("\n*  5 -> List all contacts starting with a given letter...  *\n");
	printf("************************************************************");
	printf("\n*        6 -> List all birthdays in a given month...       *\n");
	printf("************************************************************");
	printf("\n*                       7 -> Exit                          *\n");
	printf("************************************************************\n\n");

	printf("Please, choose a option: ");
	scanf("%d", &num);
	flush_in();

	return num;

}